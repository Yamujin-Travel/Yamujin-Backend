from django.db import models
from django.contrib.auth.models import AbstractUser
from allauth.account.adapter import DefaultAccountAdapter

USER_FIELDS = ['username', 'nickname', 'first_name', 'last_name', 'email', 'profile_img']

class User(AbstractUser):
    username = models.CharField(max_length=50, unique=True)
    nickname = models.CharField(max_length=50)
    email = models.EmailField(max_length=300, blank=True, null=True)
    profile_img = models.ImageField(upload_to='image/', default='image/user.png')
    
    USERNAME_FIELD = 'username'

class CustomAccountAdapter(DefaultAccountAdapter):
    def save_user(self, request, user, form, commit=True):
        from allauth.account.utils import user_email, user_username
        data = form.cleaned_data

        user_email(user, data.get('email'))
        user_username(user, data.get('username'))

        for field in USER_FIELDS:
            if data.get(field):
                setattr(user, field, data.get(field))

        if 'password1' in data:
            user.set_password(data['password1'])
        else:
            user.set_unusable_password()

        self.populate_username(request, user)

        if commit:
            user.save()

        return user