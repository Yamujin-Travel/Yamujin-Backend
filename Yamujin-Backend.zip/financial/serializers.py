from rest_framework import serializers
from .models import *

class BaseOptionSerializer(serializers.ModelSerializer):
    class Meta:
        read_only_fields = ('deposit', 'saving')

class DepositOptionSerializer(BaseOptionSerializer):
    class Meta(BaseOptionSerializer.Meta):
        model = DepositOption
        fields = '__all__'

class SavingOptionSerializer(BaseOptionSerializer):
    class Meta(BaseOptionSerializer.Meta):
        model = SavingOption
        fields = '__all__'

class BaseOptionSerializer2(serializers.ModelSerializer):
    class Meta:
        fields = '__all__'

class DepositOptionSerializer2(BaseOptionSerializer2):
    deposit = DepositOptionSerializer()
    class Meta(BaseOptionSerializer2.Meta):
        model = DepositOption

class SavingOptionSerializer2(BaseOptionSerializer2):
    saving = SavingOptionSerializer()
    class Meta(BaseOptionSerializer2.Meta):
        model = SavingOption

class BaseContractSerializer(serializers.ModelSerializer):
    class Meta:
        read_only_fields = ('contract_user',)

class DepositSerializer(BaseContractSerializer):
    depositoption_set = DepositOptionSerializer(many=True, read_only=True)
    depositoption2_set = DepositOptionSerializer2(many=True, read_only=True)
    class Meta(BaseContractSerializer.Meta):
        model = Deposit
        fields = '__all__'

class SavingSerializer(BaseContractSerializer):
    savingoption_set = SavingOptionSerializer(many=True, read_only=True)
    class Meta(BaseContractSerializer.Meta):
        model = Saving
        fields = '__all__'

class ContractDepositSerializer(DepositSerializer):
    class Meta(DepositSerializer.Meta):
        model = Deposit
        fields = ('deposit_code','name', 'kor_co_nm', 'depositoption_set')

class ContractSavingSerializer(SavingSerializer):
    class Meta(SavingSerializer.Meta):
        model = Saving
        fields = ('saving_code','name','kor_co_nm', 'savingoption_set')